import unittest
from currency_rate_viewer.analytics import AnalyticsEngine
from currency_rate_viewer.models import Transaction

class TestAnalyticsEngine(unittest.TestCase):
    def test_compute_summary(self):
        txns = [
            Transaction(id="t1", timestamp="2026-11-20T10:00:00", from_currency="USD", to_currency="EUR", amount=100.0, converted_amount=92.5, rate=0.925, usd_equivalent=100.0),
            Transaction(id="t2", timestamp="2026-11-20T11:00:00", from_currency="GBP", to_currency="USD", amount=100.0, converted_amount=126.9, rate=1.269, usd_equivalent=126.9)
        ]
        summary = AnalyticsEngine.compute_summary(txns)
        self.assertEqual(summary['total_transactions'], 2)
        self.assertAlmostEqual(summary['total_volume_usd'], 226.9)

if __name__ == '__main__':
    unittest.main()
