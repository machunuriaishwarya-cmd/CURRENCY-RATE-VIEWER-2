import unittest
import os
from currency_rate_viewer.engine import ConversionEngine
from currency_rate_viewer.storage import StorageManager

class TestConversionEngine(unittest.TestCase):
    def setUp(self):
        self.storage = StorageManager("temp_j.json", "temp_c.csv", "temp_a.log")
        self.engine = ConversionEngine(self.storage)

    def tearDown(self):
        for f in ["temp_j.json", "temp_c.csv", "temp_a.log"]:
            if os.path.exists(f):
                os.remove(f)

    def test_convert_and_search(self):
        txn, is_live, msg = self.engine.convert_and_store("USD", "GBP", 200.0, notes="Test Search Note")
        results = self.engine.search_transactions(query="Search Note")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].id, txn.id)

if __name__ == '__main__':
    unittest.main()
