import unittest
from currency_rate_viewer.models import Transaction

class TestTransactionModel(unittest.TestCase):
    def test_valid_transaction(self):
        t = Transaction(id="t1", timestamp="2026-11-20T10:00:00", from_currency="USD", to_currency="EUR", amount=100.0, converted_amount=92.5, rate=0.925, usd_equivalent=100.0)
        self.assertTrue(t.validate())

    def test_invalid_currency(self):
        t = Transaction(id="t2", timestamp="2026-11-20T10:00:00", from_currency="INVALID", to_currency="EUR", amount=100.0, converted_amount=92.5, rate=0.925)
        with self.assertRaises(ValueError):
            t.validate()

    def test_negative_amount(self):
        t = Transaction(id="t3", timestamp="2026-11-20T10:00:00", from_currency="USD", to_currency="EUR", amount=-50.0, converted_amount=-46.25, rate=0.925)
        with self.assertRaises(ValueError):
            t.validate()

if __name__ == '__main__':
    unittest.main()
