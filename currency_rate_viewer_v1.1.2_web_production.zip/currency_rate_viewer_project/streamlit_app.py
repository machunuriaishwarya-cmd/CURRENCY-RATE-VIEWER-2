"""
Currency Rate Viewer - Streamlit Web Dashboard Interface
Production-grade Web UI for Demonstrations & Hackathon Submissions
"""

import os
import sys
import datetime
import pandas as pd
import streamlit as st

# Add current directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from currency_rate_viewer.config import SUPPORTED_CURRENCIES
from currency_rate_viewer.engine import Engine
from currency_rate_viewer.exporter import Exporter

st.set_page_config(
    page_title="Currency Rate Viewer - Web Dashboard",
    page_icon="💱",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling for high-contrast executive visual presentation
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E88E5;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.0rem;
        color: #555555;
        margin-bottom: 1.5rem;
    }
    .stButton>button {
        background-color: #1E88E5;
        color: white;
        border-radius: 6px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def get_engine():
    data_dir = os.path.dirname(os.path.abspath(__file__))
    return Engine(data_dir=data_dir)

def main():
    engine = get_engine()
    st.sidebar.title("💱 Currency Rate Viewer")
    st.sidebar.caption("v1.1.0 Web Production Release")
    st.sidebar.markdown("---")
    
    navigation = st.sidebar.radio(
        "Navigation Menu",
        ["💱 Live Rate Converter", "📊 Analytics & Trends", "📋 Transaction History", "⚙️ System & Exporters"]
    )
    
    engine.refresh_cache()
    records = engine.get_all_records()
    st.sidebar.markdown("---")
    st.sidebar.metric("Total Stored Records", len(records))
    
    if navigation == "💱 Live Rate Converter":
        st.markdown('<div class="main-header">💱 Real-Time Currency Converter</div>', unsafe_allow_html=True)
        st.markdown('<div class="sub-header">Convert between 10 supported currencies with live exchange rates & offline fallback cache.</div>', unsafe_allow_html=True)
        
        col1, col2 = st.columns([1, 1])
        with col1:
            st.subheader("Conversion Parameters")
            from_curr = st.selectbox("From Currency (Source)", SUPPORTED_CURRENCIES, index=0)
            to_curr = st.selectbox("To Currency (Target)", SUPPORTED_CURRENCIES, index=1)
            amount = st.number_input("Amount to Convert", min_value=0.01, value=100.0, step=10.0, format="%.2f")
            note = st.text_input("Transaction Note (Optional)", placeholder="e.g. Supplier payment")
            convert_btn = st.button("Execute Currency Conversion", use_container_width=True)
            
        with col2:
            st.subheader("Live Exchange Rate & Output")
            if convert_btn or amount > 0:
                record, err = engine.convert_and_log(from_curr, to_curr, amount, note)
                if err:
                    st.error(f"Conversion Error: {err}")
                elif record:
                    st.success("Conversion Recorded Successfully!")
                    mcol1, mcol2 = st.columns(2)
                    with mcol1:
                        st.metric("Exchange Rate", f"1 {from_curr} = {record.rate:.4f} {to_curr}")
                        st.metric("Source Amount", f"{record.amount:,.2f} {from_curr}")
                    with mcol2:
                        st.metric("Converted Value", f"{record.converted_amount:,.2f} {to_curr}")
                        st.metric("Est. USD Equivalent", f"${record.usd_equivalent:,.2f} USD")
                    st.info(f"**Transaction ID**: `{record.id}` | **Timestamp**: `{record.timestamp}`")

    elif navigation == "📊 Analytics & Trends":
        st.markdown('<div class="main-header">📊 Executive Analytics & Visual Trends</div>', unsafe_allow_html=True)
        metrics = engine.get_summary_metrics()
        
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Transactions", metrics["total_transactions"])
        col2.metric("Total Volume (USD)", f"${metrics['total_usd_volume']:,.2f}")
        col3.metric("Average Transaction", f"${metrics['average_usd_volume']:,.2f}")
        col4.metric("Top Pair", metrics.get("most_frequent_pair", "N/A"))
        
        st.markdown("---")
        chart_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "currency_trends.png")
        if os.path.exists(chart_path):
            st.image(chart_path, caption="Visual Analytics Dashboard", use_column_width=True)

    elif navigation == "📋 Transaction History":
        st.markdown('<div class="main-header">📋 Filterable Transaction Log</div>', unsafe_allow_html=True)
        search_query = st.text_input("🔍 Search by Currency Code or Note Keyword", placeholder="e.g. JPY, EUR, supplier")
        filtered_records = engine.search_records(search_query) if search_query else records
        if filtered_records:
            df = pd.DataFrame([r.to_dict() for r in filtered_records])
            st.dataframe(df, use_container_width=True)
            
            csv_data = df.to_csv(index=False).encode('utf-8')
            st.download_button("Download Transactions (CSV)", data=csv_data, file_name="currency_transactions.csv", mime="text/csv")

    elif navigation == "⚙️ System & Exporters":
        st.markdown('<div class="main-header">⚙️ System Status & Exporters</div>', unsafe_allow_html=True)
        if st.button("Generate Summary Reports", use_container_width=True):
            exporter = Exporter(engine.storage, engine.analytics)
            md_path, html_path = exporter.export_all_reports(engine.get_summary_metrics())
            st.success(f"""Reports Generated!
- `{md_path}`
- `{html_path}`""")

if __name__ == "__main__":
    main()
