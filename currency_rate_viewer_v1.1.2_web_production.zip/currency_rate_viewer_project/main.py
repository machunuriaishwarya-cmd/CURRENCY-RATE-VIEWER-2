"""
Currency Rate Viewer - Main Entry Point
"""

import sys
import os
import argparse
from currency_rate_viewer.engine import ConversionEngine
from currency_rate_viewer.analytics import AnalyticsEngine
from currency_rate_viewer.exporter import Exporter
from currency_rate_viewer.cli import CommandLineInterface
from currency_rate_viewer.config import APP_NAME, APP_VERSION

def generate_seed_data(engine: ConversionEngine):
    import random
    from datetime import datetime, timedelta

    currencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "INR", "SGD"]
    notes_list = ["Software Subscription", "Cloud Hosting", "Travel Expenses", "Consulting Fee", "Equipment Purchase", "License Renewal", "Domain Registration", "Team Lunch", "Conference Ticket"]

    print("Seeding production dataset (40 records)...")
    engine.transactions.clear()

    now = datetime.now()
    for i in range(40):
        dt = now - timedelta(days=random.randint(0, 30), hours=random.randint(0, 23), minutes=random.randint(0, 59))
        f_curr = random.choice(currencies)
        t_curr = random.choice([c for c in currencies if c != f_curr])
        amt = round(random.uniform(50.0, 4500.0), 2)
        if i % 8 == 0:
            amt = round(random.uniform(6000.0, 15000.0), 2)

        note = random.choice(notes_list)
        txn, _, _ = engine.convert_and_store(f_curr, t_curr, amt, note)
        txn.timestamp = dt.isoformat(timespec='seconds')

    engine.storage.save_transactions(engine.transactions)
    print(f"Successfully seeded {len(engine.transactions)} records.")

def main():
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{APP_VERSION} - Smart Exchange Rate Application")
    parser.add_argument('--cli', action='store_true', help="Launch Interactive Terminal UI (Default)")
    parser.add_argument('--gui', action='store_true', help="Launch Desktop Graphical UI (Tkinter)")
    parser.add_argument('--streamlit', action='store_true', help="Launch Web Interface (Streamlit Dashboard)")
    parser.add_argument('--demo', action='store_true', help="Run Non-Interactive Integration Demo")
    parser.add_argument('--seed', action='store_true', help="Re-seed sample dataset with 40 records")
    parser.add_argument('--export', action='store_true', help="Export Markdown and HTML reports non-interactively")
    parser.add_argument('--version', action='store_true', help="Show version info")

    args = parser.parse_args()

    if args.version:
        print(f"{APP_NAME} v{APP_VERSION}")
        sys.exit(0)

    engine = ConversionEngine()

    if args.seed:
        generate_seed_data(engine)

    if not engine.transactions:
        generate_seed_data(engine)

    if args.demo:
        print("=== AUTOMATED PRODUCTION INTEGRATION TEST & DEMO ===")
        print(f"Loaded {len(engine.transactions)} records.")
        summary = AnalyticsEngine.compute_summary(engine.transactions)
        print(f"Total Transactions : {summary['total_transactions']}")
        print(f"Total USD Volume   : ${summary['total_volume_usd']:,.2f}")
        print(f"Average Size       : ${summary['avg_volume_usd']:,.2f}")
        
        AnalyticsEngine.generate_visual_plots(engine.transactions, "currency_trends.png")
        Exporter.export_markdown_report(summary, "summary_report.md")
        Exporter.export_html_report(summary, "summary_report.html")
        print("Demo completed with zero errors.")
        sys.exit(0)

    if args.export:
        summary = AnalyticsEngine.compute_summary(engine.transactions)
        Exporter.export_markdown_report(summary, "summary_report.md")
        Exporter.export_html_report(summary, "summary_report.html")
        print("Reports exported successfully.")
        sys.exit(0)

    if args.streamlit:
        print("Launching Streamlit Web Dashboard...")
        os.system(f"streamlit run {os.path.join(os.path.dirname(__file__), 'streamlit_app.py')}")
        sys.exit(0)

    if args.gui:
        try:
            from currency_rate_viewer.gui import LaunchGUI
            LaunchGUI(engine)
        except Exception as e:
            print(f"GUI Error: {e}. Falling back to CLI.")
            cli = CommandLineInterface(engine)
            cli.run()
    else:
        cli = CommandLineInterface(engine)
        cli.run()

if __name__ == '__main__':
    main()
