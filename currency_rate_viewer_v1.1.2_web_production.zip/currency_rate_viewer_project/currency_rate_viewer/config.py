"""
Application Configuration & Constants
"""

APP_NAME = "Currency Rate Viewer"
APP_VERSION = "1.0.0"
DEFAULT_BASE_CURRENCY = "USD"

SUPPORTED_CURRENCIES = [
    "USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "INR", "SGD", 
    "NZD", "HKD", "BRL", "ZAR", "KRW"
]

API_ENDPOINT = "https://open.er-api.com/v6/latest/"
API_TIMEOUT = 5.0  # seconds

# Fallback offline exchange rates relative to USD (1 USD = X Currency)
OFFLINE_MOCK_RATES = {
    "USD": 1.0000,
    "EUR": 0.9250,
    "GBP": 0.7880,
    "JPY": 154.50,
    "AUD": 1.5240,
    "CAD": 1.3680,
    "CHF": 0.9120,
    "CNY": 7.2350,
    "INR": 83.450,
    "SGD": 1.3520,
    "NZD": 1.6480,
    "HKD": 7.8120,
    "BRL": 5.1500,
    "ZAR": 18.250,
    "KRW": 1365.0,
}

DEFAULT_JSON_FILE = "conversions.json"
DEFAULT_CSV_FILE = "conversions.csv"
DEFAULT_AUDIT_LOG = "audit.log"
DEFAULT_REPORT_MD = "summary_report.md"
DEFAULT_REPORT_HTML = "summary_report.html"
DEFAULT_PLOT_PNG = "currency_trends.png"

# Threshold Flags for Audit & Analysis
HIGH_VOLUME_THRESHOLD_USD = 5000.0  # Transactions above $5k equivalent flagged
VOLATILITY_WARNING_THRESHOLD = 0.08  # 8% deviation from baseline rates
