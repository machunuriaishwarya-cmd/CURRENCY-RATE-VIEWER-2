"""
Tkinter Desktop Graphical User Interface (GUI)
"""

import sys
from typing import Optional
from .engine import ConversionEngine
from .analytics import AnalyticsEngine
from .exporter import Exporter

def LaunchGUI(engine: ConversionEngine):
    try:
        import tkinter as tk
        from tkinter import ttk, messagebox
    except ImportError:
        raise RuntimeError("Tkinter library not available in Python environment.")

    # Check for headless display environment
    import os
    if sys.platform.startswith('linux') and not os.environ.get('DISPLAY'):
        raise RuntimeError("No graphical display found (Headless Environment).")

    root = tk.Tk()
    root.title("Currency Rate Viewer - Production Desktop GUI")
    root.geometry("850x600")

    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True, padx=10, pady=10)

    # --- TAB 1: Live Converter ---
    tab_convert = ttk.Frame(notebook)
    notebook.add(tab_convert, text="Live Rate Converter")

    lbl_title = ttk.Label(tab_convert, text="Currency Converter Engine", font=("Helvetica", 16, "bold"))
    lbl_title.pack(pady=15)

    frame_form = ttk.Frame(tab_convert)
    frame_form.pack(pady=10)

    ttk.Label(frame_form, text="Source Currency (ISO):").grid(row=0, column=0, padx=5, pady=5, sticky='e')
    entry_from = ttk.Entry(frame_form)
    entry_from.insert(0, "USD")
    entry_from.grid(row=0, column=1, padx=5, pady=5)

    ttk.Label(frame_form, text="Target Currency (ISO):").grid(row=1, column=0, padx=5, pady=5, sticky='e')
    entry_to = ttk.Entry(frame_form)
    entry_to.insert(0, "EUR")
    entry_to.grid(row=1, column=1, padx=5, pady=5)

    ttk.Label(frame_form, text="Amount:").grid(row=2, column=0, padx=5, pady=5, sticky='e')
    entry_amount = ttk.Entry(frame_form)
    entry_amount.insert(0, "100.00")
    entry_amount.grid(row=2, column=1, padx=5, pady=5)

    ttk.Label(frame_form, text="Transaction Note:").grid(row=3, column=0, padx=5, pady=5, sticky='e')
    entry_notes = ttk.Entry(frame_form)
    entry_notes.insert(0, "GUI Conversion")
    entry_notes.grid(row=3, column=1, padx=5, pady=5)

    lbl_result = ttk.Label(tab_convert, text="", font=("Helvetica", 14), foreground="green")
    lbl_result.pack(pady=15)

    def do_convert():
        try:
            f_curr = entry_from.get().strip().upper()
            t_curr = entry_to.get().strip().upper()
            amt = float(entry_amount.get().strip())
            notes = entry_notes.get().strip()

            txn, is_live, msg = engine.convert_and_store(f_curr, t_curr, amt, notes)
            lbl_result.config(text=f"Converted: {txn.converted_amount:,.2f} {txn.to_currency} (Rate: {txn.rate:.4f})")
            messagebox.showinfo("Success", f"Transaction saved! ID: {txn.id}")
            refresh_history()
        except Exception as ex:
            messagebox.showerror("Error", str(ex))

    btn_calc = ttk.Button(tab_convert, text="Execute Conversion", command=do_convert)
    btn_calc.pack(pady=10)

    # --- TAB 2: Transaction History ---
    tab_history = ttk.Frame(notebook)
    notebook.add(tab_history, text="Transaction Records")

    tree = ttk.Treeview(tab_history, columns=('id', 'timestamp', 'from', 'to', 'amount', 'converted', 'usd_eq'), show='headings')
    tree.heading('id', text='ID')
    tree.heading('timestamp', text='Timestamp')
    tree.heading('from', text='From')
    tree.heading('to', text='To')
    tree.heading('amount', text='Amount')
    tree.heading('converted', text='Converted')
    tree.heading('usd_eq', text='USD Eq.')
    tree.pack(fill='both', expand=True, padx=10, pady=10)

    def refresh_history():
        for i in tree.get_children():
            tree.delete(i)
        for t in sorted(engine.transactions, key=lambda x: x.timestamp, reverse=True):
            tree.insert('', 'end', values=(t.id, t.timestamp, t.from_currency, t.to_currency, f"{t.amount:.2f}", f"{t.converted_amount:.2f}", f"${t.usd_equivalent:.2f}"))

    refresh_history()

    # --- TAB 3: Reports & Export ---
    tab_export = ttk.Frame(notebook)
    notebook.add(tab_export, text="Analytics & Exports")

    def do_export_md():
        s = AnalyticsEngine.compute_summary(engine.transactions)
        Exporter.export_markdown_report(s, "summary_report.md")
        messagebox.showinfo("Export", "Saved summary_report.md")

    def do_plot():
        AnalyticsEngine.generate_visual_plots(engine.transactions, "currency_trends.png")
        messagebox.showinfo("Plot", "Saved currency_trends.png")

    ttk.Button(tab_export, text="Generate Visual Analytics Plot", command=do_plot).pack(pady=15)
    ttk.Button(tab_export, text="Export Executive Summary (Markdown)", command=do_export_md).pack(pady=15)

    root.mainloop()
