"""
Currency Rate Viewer - Production Application Package
Version: 1.1.2
"""
__version__ = "1.1.2"

from .engine import ConversionEngine, Engine
from .storage import StorageManager
from .api import ExchangeRateAPI
from .analytics import AnalyticsEngine
from .exporter import Exporter
