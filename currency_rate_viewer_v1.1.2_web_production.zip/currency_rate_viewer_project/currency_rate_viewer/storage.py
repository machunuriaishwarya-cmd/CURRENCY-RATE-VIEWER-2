"""
Local Storage Persistence (JSON, CSV) and Audit Logging
"""

import json
import csv
import os
import shutil
from datetime import datetime
from typing import List, Tuple
from .models import Transaction
from .config import DEFAULT_JSON_FILE, DEFAULT_CSV_FILE, DEFAULT_AUDIT_LOG

class StorageManager:
    def __init__(self, json_file: str = DEFAULT_JSON_FILE, csv_file: str = DEFAULT_CSV_FILE, audit_log: str = DEFAULT_AUDIT_LOG):
        self.json_file = json_file
        self.csv_file = csv_file
        self.audit_log = audit_log

    def load_transactions(self) -> Tuple[List[Transaction], str]:
        transactions = []
        msg = ""

        # Try JSON first
        if os.path.exists(self.json_file):
            try:
                with open(self.json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        for item in data:
                            try:
                                t = Transaction.from_dict(item)
                                t.validate()
                                transactions.append(t)
                            except Exception:
                                continue
                        return transactions, f"Loaded {len(transactions)} transactions from JSON ({self.json_file})."
            except (json.JSONDecodeError, IOError) as e:
                self.backup_corrupted_file(self.json_file)
                msg += f"Warning: Corrupted JSON detected and backed up. "

        # Fallback to CSV if JSON missing or empty
        if os.path.exists(self.csv_file):
            try:
                with open(self.csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        try:
                            t = Transaction.from_csv_row(row)
                            t.validate()
                            transactions.append(t)
                        except Exception:
                            continue
                return transactions, f"Loaded {len(transactions)} transactions from CSV ({self.csv_file})."
            except Exception as e:
                msg += f"Warning: CSV read failed ({e}). "

        return [], msg + "No existing valid storage found. Starting with a fresh dataset."

    def save_transactions(self, transactions: List[Transaction]) -> Tuple[bool, str]:
        success_json = self.save_json(transactions)
        success_csv = self.save_csv(transactions)
        if success_json and success_csv:
            return True, f"Successfully persisted {len(transactions)} records to JSON and CSV."
        elif success_json or success_csv:
            return True, f"Partially saved records to storage (JSON: {success_json}, CSV: {success_csv})."
        else:
            return False, "Failed to persist records to local storage."

    def save_json(self, transactions: List[Transaction]) -> bool:
        try:
            temp_file = f"{self.json_file}.tmp"
            data = [t.to_dict() for t in transactions]
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            shutil.move(temp_file, self.json_file)
            return True
        except Exception:
            return False

    def save_csv(self, transactions: List[Transaction]) -> bool:
        try:
            temp_file = f"{self.csv_file}.tmp"
            fieldnames = ['id', 'timestamp', 'from_currency', 'to_currency', 'amount', 'converted_amount', 'rate', 'notes', 'tags', 'usd_equivalent']
            with open(temp_file, 'w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for t in transactions:
                    writer.writerow(t.to_csv_row())
            shutil.move(temp_file, self.csv_file)
            return True
        except Exception:
            return False

    def backup_corrupted_file(self, filepath: str):
        if os.path.exists(filepath):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{filepath}.corrupted_{timestamp}.bak"
            try:
                shutil.copy(filepath, backup_path)
            except Exception:
                pass

    def log_audit(self, action: str, details: str):
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_line = f"[{timestamp}] [{action.upper()}] {details}\n"
            with open(self.audit_log, 'a', encoding='utf-8') as f:
                f.write(log_line)
        except Exception:
            pass
