"""
Data Models and Data Classes
"""

import uuid
from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Dict, Any, List
from .utils import validate_currency_code

@dataclass
class Transaction:
    id: str
    timestamp: str
    from_currency: str
    to_currency: str
    amount: float
    converted_amount: float
    rate: float
    notes: str = ""
    tags: List[str] = field(default_factory=list)
    usd_equivalent: float = 0.0

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())[:8]
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat(timespec='seconds')
        self.from_currency = self.from_currency.upper().strip()
        self.to_currency = self.to_currency.upper().strip()
        self.amount = float(self.amount)
        self.converted_amount = float(self.converted_amount)
        self.rate = float(self.rate)
        self.usd_equivalent = float(self.usd_equivalent)

    def validate(self) -> bool:
        if not validate_currency_code(self.from_currency):
            raise ValueError(f"Invalid from_currency ISO code: {self.from_currency}")
        if not validate_currency_code(self.to_currency):
            raise ValueError(f"Invalid to_currency ISO code: {self.to_currency}")
        if self.amount < 0:
            raise ValueError("Amount cannot be negative.")
        if self.rate <= 0:
            raise ValueError("Exchange rate must be positive.")
        return True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Transaction':
        return cls(
            id=data.get('id', str(uuid.uuid4())[:8]),
            timestamp=data.get('timestamp', datetime.now().isoformat(timespec='seconds')),
            from_currency=data.get('from_currency', 'USD'),
            to_currency=data.get('to_currency', 'EUR'),
            amount=float(data.get('amount', 0.0)),
            converted_amount=float(data.get('converted_amount', 0.0)),
            rate=float(data.get('rate', 1.0)),
            notes=data.get('notes', ''),
            tags=data.get('tags', []),
            usd_equivalent=float(data.get('usd_equivalent', 0.0))
        )

    def to_csv_row(self) -> Dict[str, str]:
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'from_currency': self.from_currency,
            'to_currency': self.to_currency,
            'amount': f"{self.amount:.2f}",
            'converted_amount': f"{self.converted_amount:.2f}",
            'rate': f"{self.rate:.6f}",
            'notes': self.notes,
            'tags': ",".join(self.tags),
            'usd_equivalent': f"{self.usd_equivalent:.2f}"
        }

    @classmethod
    def from_csv_row(cls, row: Dict[str, str]) -> 'Transaction':
        tags_raw = row.get('tags', '')
        tags_list = [t.strip() for t in tags_raw.split(',') if t.strip()] if tags_raw else []
        return cls(
            id=row.get('id', str(uuid.uuid4())[:8]),
            timestamp=row.get('timestamp', datetime.now().isoformat(timespec='seconds')),
            from_currency=row.get('from_currency', 'USD'),
            to_currency=row.get('to_currency', 'EUR'),
            amount=float(row.get('amount', 0.0)),
            converted_amount=float(row.get('converted_amount', 0.0)),
            rate=float(row.get('rate', 1.0)),
            notes=row.get('notes', ''),
            tags=tags_list,
            usd_equivalent=float(row.get('usd_equivalent', 0.0))
        )
